class IncompleteVoteError(Exception):
    pass

class NoWinnerError(Exception):
    pass

class InvalidVoteError(Exception):
    pass

class FailedElectionError(Exception):
    pass
