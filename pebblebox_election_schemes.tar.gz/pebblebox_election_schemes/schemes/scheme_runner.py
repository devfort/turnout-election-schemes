class SchemeRunner(object):
    def run(self, stream):
        raise NotImplementedError()

    def plain_text_report(self, report):
        raise NotImplementedError()
