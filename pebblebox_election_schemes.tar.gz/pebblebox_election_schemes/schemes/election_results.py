class ElectionResults(object):
    def __init__(self, outcome, report):
        self.outcome = outcome
        self.report = report
